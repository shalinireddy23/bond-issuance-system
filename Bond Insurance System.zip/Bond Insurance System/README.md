# Bond Issuance System

Spring Boot service for corporate bond issuance, subscriptions, allocation, coupons, and maturity payments.

## Run

Requirements: Java 17 and Maven 3.9+.

```powershell
mvn spring-boot:run
```

Swagger UI: http://localhost:8080/swagger-ui.html
H2 console: http://localhost:8080/h2-console
Investor UI: http://localhost:8080/index.html

The persisted operational date is controlled through `/api/system/date`, `/api/system/advance-date`, and `/api/system/reset`. Investor APIs require `X-User-Id` with one of `INV-001` through `INV-005`.

## API shape

- `/api/v1/...`: snake_case compatibility responses
- `/api/v2/...`: camelCase compatibility responses

The service includes validated CSV bond ingestion, optional SFTP polling, system-date controls, lifecycle processing, allocation, coupon and maturity payments, portfolio APIs, and v1/v2 DTO mappings.

SFTP polling is configured through the `bis.sftp.*` properties in `application.yml` and polls `/upload/bonds`.
