# Bond Issuance System

## 1. Project Overview

The Bond Issuance System (BIS) manages corporate bonds from file ingestion through subscription, allocation, coupon payments, maturity, and investor portfolio viewing.

The application is a Spring Boot backend with a static investor dashboard. It uses Java 17, Spring Data JPA, Flyway, H2, and Maven.

## 2. Technology Stack

- Java 17
- Spring Boot 3.5.4
- Spring MVC
- Spring Data JPA and Hibernate
- Flyway database migrations
- H2 file database
- Apache Commons CSV
- JSch SFTP client
- Springdoc OpenAPI / Swagger UI
- Maven 3.9+

## 3. Running the Application

### Requirements

- Java 17+
- Maven 3.9+
- Optional SFTP server for remote bond ingestion

### Start

```powershell
mvn spring-boot:run
```

If Maven is not on the current terminal PATH, use the installed executable directly:

```powershell
& "$env:LOCALAPPDATA\Programs\Apache Maven\apache-maven-3.9.10\bin\mvn.cmd" spring-boot:run
```

### URLs

- Investor dashboard: http://localhost:8080/index.html
- Swagger UI: http://localhost:8080/swagger-ui.html
- H2 console: http://localhost:8080/h2-console

### Test

```powershell
mvn test
```

The current test suite covers application startup, CSV validation, duplicate uploads, proportional allocation, coupon processing, and maturity processing.

## 4. Application Structure

```text
src/main/java/com/bis/
  BondIssuanceApplication.java       Spring Boot entry point
  domain/                             JPA entities and lifecycle enums
  repository/                         Spring Data repositories
  service/                            Business logic and integrations
  web/                                REST controllers, DTOs, and request filtering

src/main/resources/
  application.yml                     Runtime configuration
  db/migration/V1__create_schema.sql  Initial Flyway schema
  static/                             Investor dashboard assets

src/test/java/com/bis/
  BondIssuanceApplicationTests.java   Context startup test
  service/                            Import and lifecycle tests
```

## 5. Domain Model

### Bond

A bond contains:

- ISIN
- Issuer name
- Bond name
- Currency
- Face value
- Daily coupon rate
- Total size
- Book open and close dates
- Maturity date
- Lifecycle status

Bond statuses:

```text
PENDING -> OPEN -> CLOSED -> ALLOCATED -> MATURED
              |
              +-> CANCELLED
```

Cancellation is allowed while a bond is `PENDING` or `OPEN`.

### Subscription

A subscription contains:

- Investor ID
- Bond
- Requested quantity
- Allocated quantity
- Creation timestamp
- Subscription status

Subscription statuses:

- `PENDING`
- `ALLOCATED`
- `REJECTED`

Each investor can subscribe only once per bond. This is enforced by a database unique constraint.

### Payments

The database stores:

- Coupon payments, unique per subscription and payment date.
- Maturity payments, unique per subscription.
- Processed upload filenames, unique per filename.

## 6. Bond Import

### Multipart upload

```http
POST /api/system/uploads/bonds
Content-Type: multipart/form-data
```

The multipart field is named `file`.

Example:

```powershell
curl.exe -X POST http://localhost:8080/api/system/uploads/bonds -F "file=@bonds.csv"
```

Successful response:

```json
{
  "filename": "BONDS_20260601_001.csv",
  "imported_count": 2
}
```

### CSV header

The header must exactly match:

```csv
isin,issuerName,bondName,currency,faceValue,couponRate,maturityDate,totalSize,bookOpenDate,bookCloseDate
```

### Validation

The importer validates:

- ISIN is exactly 12 alphanumeric characters.
- ISIN is unique within the file and database.
- Issuer and bond names are non-empty and at most 255 characters.
- Currency is a valid ISO currency code.
- Face value is positive, at most 2 decimal places, and no greater than 1,000,000.
- Coupon rate is greater than 0 and less than 1, with at most 4 decimal places.
- Total size is a positive integer no greater than 100,000,000.
- Dates use ISO `YYYY-MM-DD` format.
- Book open date is before book close date.
- Book close date is before maturity date.
- Duplicate filenames are rejected.
- Malformed rows fail the complete file transaction.

Imported bonds start in `PENDING` status.

### SFTP polling

SFTP polling is configured in [application.yml](src/main/resources/application.yml):

```yaml
bis:
  sftp:
    enabled: true
    host: localhost
    port: 2222
    username: bonduser
    password: bondpass
    remote-directory: /upload/bonds
    poll-delay-ms: 30000
```

Only files matching this pattern are processed:

```text
BONDS_YYYYMMDD_NNN.csv
```

A temporary SFTP outage is logged and does not stop future polling attempts.

## 7. Subscription Flow

Subscriptions require a valid `X-User-Id` header:

```text
INV-001
INV-002
INV-003
INV-004
INV-005
```

The business date must be within the inclusive book window, and the bond must be `OPEN`.

### v1

```http
POST /api/v1/bonds/{isin}/subscribe
X-User-Id: INV-001
Content-Type: application/json
```

```json
{
  "quantity": 1000
}
```

### v2

```http
POST /api/v2/bonds/{isin}/subscribe
X-User-Id: INV-001
Content-Type: application/json
```

The v2 response uses camelCase and includes `createdAt` as an ISO timestamp.

## 8. Lifecycle Processing

The operational date is persisted in the database and advances only through the system endpoint.

```http
GET /api/system/date
POST /api/system/advance-date
POST /api/system/reset
```

Advancing the date triggers:

1. `PENDING` bonds become `OPEN` when the book opens.
2. `OPEN` bonds become `CLOSED` after the book close date.
3. Closed bonds are allocated.
4. Coupons are generated for allocated bonds on business days.
5. Maturity principal is paid on the maturity date or next business day.
6. Bonds become `MATURED` after maturity payment.

The configured system timezone is `Asia/Kuala_Lumpur`.

### Cancellation

```http
POST /api/system/bonds/{isin}/cancel
```

Only `PENDING` and `OPEN` bonds can be cancelled. Their subscriptions become `REJECTED`.

## 9. Allocation

If total requested quantity is within total bond size, each subscription receives its full quantity.

For oversubscription:

```text
allocated = floor(requested quantity / total requested quantity * total bond size)
```

Subscriptions receiving zero are marked `REJECTED`.

The bond row is pessimistically locked during subscription creation to serialize competing subscriptions.

## 10. Coupon and Maturity Payments

Coupon formula:

```text
faceValue * couponRate * allocatedQuantity
```

Coupons are created only on Monday through Friday and stop after the maturity date. The current implementation includes the maturity business date coupon before creating the maturity payment.

Maturity formula:

```text
faceValue * allocatedQuantity
```

All financial calculations use `BigDecimal` and database decimal columns.

## 11. Portfolio APIs

### v1

```http
GET /api/v1/portfolio
X-User-Id: INV-001
```

The v1 response uses snake_case fields and flat structures.

### v2

```http
GET /api/v2/portfolio
X-User-Id: INV-001
```

The v2 response uses camelCase, nested bond details, string monetary amounts, payment types, and ISO timestamps.

Portfolio data is filtered by the requested investor ID.

## 12. Bond APIs

### v1

```http
GET /api/v1/bonds
GET /api/v1/bonds/{isin}
```

Responses use snake_case field names.

### v2

```http
GET /api/v2/bonds
GET /api/v2/bonds/{isin}
```

Responses use camelCase and string values for monetary fields.

## 13. Error Handling

The API maps common failures to structured responses:

- `400 BAD_REQUEST`: invalid input, missing header, invalid user, malformed CSV.
- `409 CONFLICT`: duplicate subscription, duplicate upload, invalid lifecycle operation.
- `404 NOT_FOUND`: missing bond reads return not found.

Example:

```json
{
  "code": "CONFLICT",
  "message": "Investor already subscribed",
  "timestamp": "2026-08-17T12:00:00Z"
}
```

## 14. Database

The application uses an H2 file database:

```text
jdbc:h2:file:./data/bis
```

Flyway owns schema creation. Hibernate runs with `ddl-auto: validate`, so entity/schema mismatches fail during startup instead of silently changing the database.

## 15. Requirement Notes

The specification contains one conflict:

- Subscription rules say concurrent subscriptions must not exceed remaining capacity.
- The worked example explicitly allows total requested quantity to exceed total bond size and then applies proportional allocation.

The implementation follows the worked example: oversubscription is allowed and allocated proportionally. A pessimistic lock serializes concurrent writes, but requests are not rejected solely because their combined quantity exceeds the bond size.

Actual SFTP connectivity requires an SFTP server at the configured host and port. The application logs connection failures and continues polling.
