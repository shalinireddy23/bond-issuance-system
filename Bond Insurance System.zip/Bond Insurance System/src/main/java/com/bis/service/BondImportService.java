package com.bis.service;

import com.bis.domain.Bond;
import com.bis.domain.BondStatus;
import com.bis.domain.ProcessedUploadFile;
import com.bis.repository.BondRepository;
import com.bis.repository.ProcessedUploadFileRepository;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.Currency;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

@Service
public class BondImportService {
    private static final List<String> HEADER = List.of("isin", "issuerName", "bondName", "currency", "faceValue",
            "couponRate", "maturityDate", "totalSize", "bookOpenDate", "bookCloseDate");
    private static final Pattern ISIN = Pattern.compile("[A-Za-z0-9]{12}");
    private final BondRepository bonds;
    private final ProcessedUploadFileRepository files;

    public BondImportService(BondRepository bonds, ProcessedUploadFileRepository files) {
        this.bonds = bonds;
        this.files = files;
    }

    @Transactional
    public int importFile(String filename, InputStream input) {
        if (filename == null || filename.isBlank()) throw new IllegalArgumentException("Filename is required");
        if (files.existsByFilename(filename)) throw new IllegalStateException("File was already processed");
        try (CSVParser parser = CSVParser.parse(new InputStreamReader(input, StandardCharsets.UTF_8),
                CSVFormat.DEFAULT.builder().setHeader().setSkipHeaderRecord(true).build())) {
            if (!parser.getHeaderNames().equals(HEADER)) throw new IllegalArgumentException("Invalid CSV header");
            Set<String> seen = new java.util.HashSet<>();
            int count = 0;
            for (CSVRecord row : parser) {
                Bond bond = parse(row);
                if (!seen.add(bond.getIsin()) || bonds.findByIsin(bond.getIsin()).isPresent()) {
                    throw new IllegalArgumentException("Duplicate ISIN: " + bond.getIsin());
                }
                bonds.save(bond);
                count++;
            }
            files.save(new ProcessedUploadFile(filename, Instant.now()));
            return count;
        } catch (IOException e) {
            throw new IllegalArgumentException("Unable to read CSV file", e);
        }
    }

    private static Bond parse(CSVRecord row) {
        if (row.size() != HEADER.size()) throw new IllegalArgumentException("Malformed row " + row.getRecordNumber());
        Bond bond = new Bond();
        String isin = text(row, "isin");
        if (!ISIN.matcher(isin).matches()) throw new IllegalArgumentException("Invalid ISIN: " + isin);
        bond.setIsin(isin);
        bond.setIssuerName(text(row, "issuerName", 255));
        bond.setBondName(text(row, "bondName", 255));
        String currency = text(row, "currency");
        try { if (!Currency.getInstance(currency).getCurrencyCode().equals(currency)) throw new Exception(); }
        catch (Exception e) { throw new IllegalArgumentException("Invalid currency: " + currency); }
        bond.setCurrency(currency);
        bond.setFaceValue(decimal(row, "faceValue", 2, BigDecimal.ZERO, BigDecimal.valueOf(1_000_000)));
        bond.setCouponRate(decimal(row, "couponRate", 4, BigDecimal.ZERO, BigDecimal.ONE));
        bond.setMaturityDate(date(row, "maturityDate"));
        String size = text(row, "totalSize");
        try {
            long totalSize = Long.parseLong(size);
            if (totalSize <= 0 || totalSize > 100_000_000) throw new Exception();
            bond.setTotalSize(totalSize);
        } catch (Exception e) { throw new IllegalArgumentException("Invalid totalSize: " + size); }
        bond.setBookOpenDate(date(row, "bookOpenDate"));
        bond.setBookCloseDate(date(row, "bookCloseDate"));
        if (!bond.getBookOpenDate().isBefore(bond.getBookCloseDate()) || !bond.getBookCloseDate().isBefore(bond.getMaturityDate())) {
            throw new IllegalArgumentException("Invalid bond date order");
        }
        bond.setStatus(BondStatus.PENDING);
        return bond;
    }

    private static String text(CSVRecord row, String name) { return text(row, name, Integer.MAX_VALUE); }
    private static String text(CSVRecord row, String name, int max) {
        String value = row.get(name).trim();
        if (value.isEmpty() || value.length() > max) throw new IllegalArgumentException("Invalid " + name);
        return value;
    }

    private static BigDecimal decimal(CSVRecord row, String name, int scale, BigDecimal minimum, BigDecimal maximum) {
        try {
            BigDecimal value = new BigDecimal(text(row, name));
            if (value.scale() > scale || value.compareTo(minimum) <= 0 || value.compareTo(maximum) > 0
                    || (name.equals("couponRate") && value.compareTo(BigDecimal.ONE) >= 0)) throw new Exception();
            return value;
        } catch (Exception e) { throw new IllegalArgumentException("Invalid " + name); }
    }

    private static LocalDate date(CSVRecord row, String name) {
        try { return LocalDate.parse(text(row, name)); }
        catch (DateTimeParseException e) { throw new IllegalArgumentException("Invalid " + name); }
    }
}