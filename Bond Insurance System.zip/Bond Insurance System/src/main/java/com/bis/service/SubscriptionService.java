package com.bis.service;

import com.bis.domain.*;
import com.bis.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;

@Service
public class SubscriptionService {
    private final BondRepository bonds;
    private final SubscriptionRepository subscriptions;
    private final BusinessDateService dates;
    public SubscriptionService(BondRepository bonds, SubscriptionRepository subscriptions, BusinessDateService dates) { this.bonds = bonds; this.subscriptions = subscriptions; this.dates = dates; }

    @Transactional
    public Subscription subscribe(String isin, String investorId, long quantity) {
        if (quantity <= 0) throw new IllegalArgumentException("Quantity must be positive");
        Bond bond = bonds.findByIsinForUpdate(isin).orElseThrow(() -> new IllegalArgumentException("Bond not found"));
        var date = dates.currentDate();
        if (bond.getStatus() != BondStatus.OPEN || date.isBefore(bond.getBookOpenDate()) || date.isAfter(bond.getBookCloseDate())) throw new IllegalStateException("Bond is not open for subscription");
        if (subscriptions.findByBondIdAndInvestorId(bond.getId(), investorId).isPresent()) throw new IllegalStateException("Investor already subscribed");
        return subscriptions.save(new Subscription(bond, investorId, quantity, Instant.now()));
    }
}
