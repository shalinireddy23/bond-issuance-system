package com.bis.service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.bis.domain.BusinessDateState;
import com.bis.repository.BusinessDateStateRepository;
import java.time.LocalDate;
import java.time.ZoneId;

@Service
public class BusinessDateService {
    private static final ZoneId ZONE = ZoneId.of("Asia/Kuala_Lumpur");
    private final BusinessDateStateRepository repository;
    private final LifecycleService lifecycle;

    public BusinessDateService(BusinessDateStateRepository repository, LifecycleService lifecycle) {
        this.repository = repository;
        this.lifecycle = lifecycle;
    }

    public LocalDate currentDate() {
        return repository.findById(1L)
                .map(BusinessDateState::getBusinessDate)
                .orElseGet(() -> initialize());
    }

    @Transactional
    public LocalDate advanceDate() {
        BusinessDateState state = state();
        state.setBusinessDate(state.getBusinessDate().plusDays(1));
        LocalDate date = repository.save(state).getBusinessDate();
        lifecycle.process(date);
        return date;
    }

    @Transactional
    public LocalDate reset() {
        BusinessDateState state = state();
        state.setBusinessDate(LocalDate.now(ZONE));
        return repository.save(state).getBusinessDate();
    }

    private LocalDate initialize() {
        return repository.save(new BusinessDateState(1L, LocalDate.now(ZONE))).getBusinessDate();
    }

    private BusinessDateState state() {
        currentDate();
        return repository.findById(1L).orElseThrow();
    }
}
