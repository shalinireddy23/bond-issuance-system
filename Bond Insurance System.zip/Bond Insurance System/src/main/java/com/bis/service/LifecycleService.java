package com.bis.service;

import com.bis.domain.*;
import com.bis.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.List;

@Service
public class LifecycleService {
    private final BondRepository bonds;
    private final SubscriptionRepository subscriptions;
    private final CouponPaymentRepository coupons;
    private final MaturityPaymentRepository maturities;

    public LifecycleService(BondRepository bonds, SubscriptionRepository subscriptions,
                            CouponPaymentRepository coupons, MaturityPaymentRepository maturities) {
        this.bonds = bonds;
        this.subscriptions = subscriptions;
        this.coupons = coupons;
        this.maturities = maturities;
    }

    @Transactional
    public void process(LocalDate date) {
        for (Bond bond : bonds.findAll()) {
            if (bond.getStatus() == BondStatus.PENDING && !date.isBefore(bond.getBookOpenDate())) bond.setStatus(BondStatus.OPEN);
            if (bond.getStatus() == BondStatus.OPEN && date.isAfter(bond.getBookCloseDate())) {
                bond.setStatus(BondStatus.CLOSED);
                allocate(bond);
            }
            if (bond.getStatus() == BondStatus.ALLOCATED) {
                processCoupon(bond, date);
                processMaturity(bond, date);
            }
        }
    }

    @Transactional
    public void cancel(String isin) {
        Bond bond = bonds.findByIsinForUpdate(isin)
                .orElseThrow(() -> new IllegalArgumentException("Bond not found"));
        if (bond.getStatus() != BondStatus.PENDING && bond.getStatus() != BondStatus.OPEN) {
            throw new IllegalStateException("Only pending or open bonds can be cancelled");
        }
        bond.setStatus(BondStatus.CANCELLED);
        subscriptions.findAllByBondId(bond.getId()).forEach(subscription -> subscription.allocate(0));
    }

    private void allocate(Bond bond) {
        List<Subscription> orders = subscriptions.findAllByBondId(bond.getId());
        long totalRequested = orders.stream().mapToLong(Subscription::getQuantity).sum();
        BigDecimal requested = BigDecimal.valueOf(totalRequested);
        BigDecimal capacity = BigDecimal.valueOf(bond.getTotalSize());
        for (Subscription subscription : orders) {
            long allocated = totalRequested <= bond.getTotalSize()
                    ? subscription.getQuantity()
                    : BigDecimal.valueOf(subscription.getQuantity()).multiply(capacity)
                        .divide(requested, 0, java.math.RoundingMode.DOWN).longValueExact();
            subscription.allocate(allocated);
        }
        bond.setStatus(BondStatus.ALLOCATED);
    }

    private void processCoupon(Bond bond, LocalDate date) {
        if (!isBusinessDay(date) || date.isAfter(bond.getMaturityDate())) return;
        for (Subscription subscription : subscriptions.findAllByBondIdAndStatus(bond.getId(), SubscriptionStatus.ALLOCATED)) {
            if (!coupons.existsBySubscriptionIdAndPaymentDate(subscription.getId(), date)) {
                BigDecimal amount = bond.getFaceValue().multiply(bond.getCouponRate())
                        .multiply(BigDecimal.valueOf(subscription.getAllocatedQuantity()));
                coupons.save(new CouponPayment(bond, subscription, date, amount));
            }
        }
    }

    private void processMaturity(Bond bond, LocalDate date) {
        LocalDate paymentDate = nextBusinessDay(bond.getMaturityDate());
        if (!date.equals(paymentDate)) return;
        for (Subscription subscription : subscriptions.findAllByBondIdAndStatus(bond.getId(), SubscriptionStatus.ALLOCATED)) {
            BigDecimal amount = bond.getFaceValue().multiply(BigDecimal.valueOf(subscription.getAllocatedQuantity()));
            maturities.save(new MaturityPayment(bond, subscription, date, amount));
        }
        bond.setStatus(BondStatus.MATURED);
    }

    private static boolean isBusinessDay(LocalDate date) {
        return date.getDayOfWeek() != DayOfWeek.SATURDAY && date.getDayOfWeek() != DayOfWeek.SUNDAY;
    }

    private static LocalDate nextBusinessDay(LocalDate date) {
        while (!isBusinessDay(date)) date = date.plusDays(1);
        return date;
    }
}