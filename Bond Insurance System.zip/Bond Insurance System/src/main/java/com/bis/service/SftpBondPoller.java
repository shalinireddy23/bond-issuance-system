package com.bis.service;

import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import java.io.InputStream;
import java.util.Properties;
import java.util.Vector;
import java.util.regex.Pattern;

@Component
public class SftpBondPoller {
    private static final Logger LOG = LoggerFactory.getLogger(SftpBondPoller.class);
    private static final Pattern BOND_FILE = Pattern.compile("BONDS_\\d{8}_\\d{3}\\.csv");
    private final BondImportService importer;
    private final boolean enabled;
    private final String host;
    private final int port;
    private final String username;
    private final String password;
    private final String remoteDirectory;

    public SftpBondPoller(BondImportService importer,
                          @Value("${bis.sftp.enabled:false}") boolean enabled,
                          @Value("${bis.sftp.host:localhost}") String host,
                          @Value("${bis.sftp.port:2222}") int port,
                          @Value("${bis.sftp.username:bonduser}") String username,
                          @Value("${bis.sftp.password:bondpass}") String password,
                          @Value("${bis.sftp.remote-directory:/upload/bonds}") String remoteDirectory) {
        this.importer = importer;
        this.enabled = enabled;
        this.host = host;
        this.port = port;
        this.username = username;
        this.password = password;
        this.remoteDirectory = remoteDirectory;
    }

    @Scheduled(fixedDelayString = "${bis.sftp.poll-delay-ms:30000}")
    public void poll() {
        if (!enabled) return;
        JSch client = new JSch();
        Session session = null;
        ChannelSftp channel = null;
        try {
            session = client.getSession(username, host, port);
            session.setPassword(password);
            Properties config = new Properties();
            config.put("StrictHostKeyChecking", "no");
            session.setConfig(config);
            session.connect();
            channel = (ChannelSftp) session.openChannel("sftp");
            channel.connect();
            @SuppressWarnings("unchecked")
            Vector<ChannelSftp.LsEntry> entries = channel.ls(remoteDirectory);
            for (ChannelSftp.LsEntry entry : entries) {
                String filename = entry.getFilename();
                if (!entry.getAttrs().isReg() || !BOND_FILE.matcher(filename).matches()) continue;
                try (InputStream input = channel.get(remoteDirectory + "/" + filename)) {
                    importer.importFile(filename, input);
                } catch (IllegalStateException alreadyProcessed) {
                    if (!alreadyProcessed.getMessage().contains("already been processed")) throw alreadyProcessed;
                }
            }
        } catch (Exception exception) {
            LOG.warn("SFTP bond polling failed: {}", exception.getMessage());
        } finally {
            if (channel != null) channel.disconnect();
            if (session != null) session.disconnect();
        }
    }
}