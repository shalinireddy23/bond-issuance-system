package com.bis.web;

import com.bis.domain.Bond;
import com.bis.repository.BondRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@RestController
public class BondController {
    private final BondRepository bonds;
    public BondController(BondRepository bonds) { this.bonds = bonds; }

    @GetMapping("/api/v1/bonds")
    public List<V1Bond> listV1() { return bonds.findAll().stream().map(BondController::v1).toList(); }

    @GetMapping("/api/v1/bonds/{isin}")
    public ResponseEntity<V1Bond> getV1(@PathVariable String isin) {
        return bonds.findByIsin(isin).map(BondController::v1).map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @GetMapping("/api/v2/bonds")
    public List<V2Bond> listV2() { return bonds.findAll().stream().map(BondController::v2).toList(); }

    @GetMapping("/api/v2/bonds/{isin}")
    public ResponseEntity<V2Bond> getV2(@PathVariable String isin) {
        return bonds.findByIsin(isin).map(BondController::v2).map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    private static V1Bond v1(Bond bond) {
        return new V1Bond(bond.getIsin(), bond.getIssuerName(), bond.getBondName(), bond.getCurrency(),
                bond.getFaceValue(), bond.getCouponRate(), bond.getMaturityDate(), bond.getTotalSize(),
                bond.getBookOpenDate(), bond.getBookCloseDate(), bond.getStatus().name());
    }

    private static V2Bond v2(Bond bond) {
        return new V2Bond(bond.getIsin(), bond.getIssuerName(), bond.getBondName(), bond.getCurrency(),
                bond.getFaceValue().toPlainString(), bond.getCouponRate().toPlainString(), bond.getMaturityDate(),
                bond.getTotalSize(), bond.getBookOpenDate(), bond.getBookCloseDate(), bond.getStatus().name());
    }

    public record V1Bond(String isin, String issuer_name, String bond_name, String currency,
                         BigDecimal face_value, BigDecimal coupon_rate, LocalDate maturity_date,
                         Long total_size, LocalDate book_open_date, LocalDate book_close_date, String status) {}

    public record V2Bond(String isin, String issuerName, String bondName, String currency,
                         String faceValue, String couponRate, LocalDate maturityDate, Long totalSize,
                         LocalDate bookOpenDate, LocalDate bookCloseDate, String status) {}
}
