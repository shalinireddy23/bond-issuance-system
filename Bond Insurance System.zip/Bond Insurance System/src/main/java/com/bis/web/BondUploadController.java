package com.bis.web;

import com.bis.service.BondImportService;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.io.IOException;
import java.util.Map;

@RestController
@RequestMapping("/api/system/uploads/bonds")
public class BondUploadController {
    private final BondImportService importer;
    public BondUploadController(BondImportService importer) { this.importer = importer; }

    @PostMapping(consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public Map<String, Object> upload(@RequestPart("file") MultipartFile file) throws IOException {
        return Map.of("filename", file.getOriginalFilename(), "imported_count",
                importer.importFile(file.getOriginalFilename(), file.getInputStream()));
    }
}