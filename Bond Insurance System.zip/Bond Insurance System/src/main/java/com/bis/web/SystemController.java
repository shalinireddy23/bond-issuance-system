package com.bis.web;

import com.bis.service.BusinessDateService;
import com.bis.service.LifecycleService;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/api/system")
public class SystemController {
    private final BusinessDateService dates;
    private final LifecycleService lifecycle;
    public SystemController(BusinessDateService dates, LifecycleService lifecycle) {
        this.dates = dates;
        this.lifecycle = lifecycle;
    }

    @GetMapping("/date")
    public Map<String, LocalDate> date() { return Map.of("business_date", dates.currentDate()); }

    @PostMapping("/advance-date")
    public Map<String, Object> advance() { return Map.of("business_date", dates.advanceDate(), "message", "Date advanced. Lifecycle events processed."); }

    @PostMapping("/reset")
    public Map<String, Object> reset() { return Map.of("business_date", dates.reset(), "message", "System reset to today's date"); }

    @PostMapping("/bonds/{isin}/cancel")
    public Map<String, String> cancel(@PathVariable String isin) {
        lifecycle.cancel(isin);
        return Map.of("isin", isin, "status", "CANCELLED");
    }
}
