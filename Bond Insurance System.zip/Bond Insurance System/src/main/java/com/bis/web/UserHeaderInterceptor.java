package com.bis.web;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;
import java.util.Set;

@Component
public class UserHeaderInterceptor implements HandlerInterceptor {
    private static final Set<String> USERS = Set.of("INV-001", "INV-002", "INV-003", "INV-004", "INV-005");
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!request.getRequestURI().contains("/subscribe") && !request.getRequestURI().contains("/portfolio")) return true;
        String user = request.getHeader("X-User-Id");
        if (user == null || !USERS.contains(user)) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Valid X-User-Id is required");
            return false;
        }
        return true;
    }
}
