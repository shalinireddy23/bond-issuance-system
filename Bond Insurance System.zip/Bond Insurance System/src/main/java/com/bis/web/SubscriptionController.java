package com.bis.web;

import com.bis.domain.Subscription;
import com.bis.service.SubscriptionService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;

@RestController
public class SubscriptionController {
    private final SubscriptionService service;
    public SubscriptionController(SubscriptionService service) { this.service = service; }

    @PostMapping("/api/v1/bonds/{isin}/subscribe")
    public V1Subscription subscribeV1(@PathVariable String isin, @RequestHeader("X-User-Id") String userId,
                                     @Valid @RequestBody SubscriptionRequest request) {
        Subscription subscription = service.subscribe(isin, userId, request.quantity());
        return new V1Subscription(subscription.getId(), subscription.getBond().getIsin(), subscription.getQuantity(),
                subscription.getStatus().name());
    }

    @PostMapping("/api/v2/bonds/{isin}/subscribe")
    public V2Subscription subscribeV2(@PathVariable String isin, @RequestHeader("X-User-Id") String userId,
                                      @Valid @RequestBody SubscriptionRequest request) {
        Subscription subscription = service.subscribe(isin, userId, request.quantity());
        return new V2Subscription(subscription.getId(), subscription.getBond().getIsin(), subscription.getQuantity(),
            subscription.getStatus().name(), subscription.getCreatedAt());
    }

    public record V1Subscription(Long id, String isin, Long quantity, String status) {}
    public record V2Subscription(Long id, String isin, Long quantity, String status, Instant createdAt) {}
}
