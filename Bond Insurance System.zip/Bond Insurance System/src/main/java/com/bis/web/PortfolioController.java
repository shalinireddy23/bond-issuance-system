package com.bis.web;

import com.bis.domain.Subscription;
import com.bis.repository.CouponPaymentRepository;
import com.bis.repository.MaturityPaymentRepository;
import com.bis.repository.SubscriptionRepository;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

@RestController
public class PortfolioController {
        private static final ZoneId ZONE = ZoneId.of("Asia/Kuala_Lumpur");
    private final SubscriptionRepository subscriptions;
    private final CouponPaymentRepository coupons;
    private final MaturityPaymentRepository maturities;

    public PortfolioController(SubscriptionRepository subscriptions, CouponPaymentRepository coupons,
                               MaturityPaymentRepository maturities) {
        this.subscriptions = subscriptions;
        this.coupons = coupons;
        this.maturities = maturities;
    }

    @GetMapping("/api/v1/portfolio")
    public V1Portfolio v1(@RequestHeader("X-User-Id") String investorId) {
        return new V1Portfolio(
                subscriptions.findAllByInvestorId(investorId).stream().map(PortfolioController::v1Subscription).toList(),
                coupons.findAllBySubscriptionInvestorId(investorId).stream().map(payment -> new V1Payment(
                        payment.getPaymentDate(), payment.getAmount().toPlainString())).toList(),
                maturities.findAllBySubscriptionInvestorId(investorId).stream().map(payment -> new V1Payment(
                        payment.getPaymentDate(), payment.getAmount().toPlainString())).toList());
    }

    @GetMapping("/api/v2/portfolio")
    public V2Portfolio v2(@RequestHeader("X-User-Id") String investorId) {
        return new V2Portfolio(
                subscriptions.findAllByInvestorId(investorId).stream().map(PortfolioController::v2Subscription).toList(),
                coupons.findAllBySubscriptionInvestorId(investorId).stream().map(payment -> new V2Payment(
                        new V2Bond(payment.getBond().getIsin(), payment.getBond().getBondName()),
                        payment.getPaymentDate().atStartOfDay(ZONE).toInstant(), payment.getAmount().toPlainString(), "COUPON")).toList(),
                maturities.findAllBySubscriptionInvestorId(investorId).stream().map(payment -> new V2Payment(
                        new V2Bond(payment.getBond().getIsin(), payment.getBond().getBondName()),
                        payment.getPaymentDate().atStartOfDay(ZONE).toInstant(), payment.getAmount().toPlainString(), "MATURITY")).toList());
    }

    private static V1Subscription v1Subscription(Subscription subscription) {
        return new V1Subscription(subscription.getBond().getIsin(), subscription.getQuantity(),
                subscription.getAllocatedQuantity(), subscription.getStatus().name());
    }

    private static V2Subscription v2Subscription(Subscription subscription) {
        return new V2Subscription(new V2Bond(subscription.getBond().getIsin(), subscription.getBond().getBondName()),
                subscription.getQuantity(), subscription.getAllocatedQuantity(), subscription.getStatus().name(),
                subscription.getCreatedAt());
    }

    public record V1Portfolio(@JsonProperty("subscriptions") List<V1Subscription> subscriptions,
                              @JsonProperty("coupon_payments") List<V1Payment> couponPayments,
                              @JsonProperty("maturity_payments") List<V1Payment> maturityPayments) {}
    public record V1Subscription(@JsonProperty("isin") String isin, @JsonProperty("quantity") Long quantity,
                                 @JsonProperty("allocated_quantity") Long allocatedQuantity,
                                 @JsonProperty("status") String status) {}
    public record V1Payment(@JsonProperty("payment_date") LocalDate paymentDate,
                            @JsonProperty("amount") String amount) {}
    public record V2Portfolio(List<V2Subscription> subscriptions, List<V2Payment> couponPayments,
                              List<V2Payment> maturityPayments) {}
        public record V2Subscription(V2Bond bond, Long quantity, Long allocatedQuantity, String status, Instant createdAt) {}
    public record V2Bond(String isin, String bondName) {}
        public record V2Payment(V2Bond bond, Instant paymentDate, String amount, String type) {}
}