package com.bis.domain;

public enum BondStatus { PENDING, OPEN, CLOSED, ALLOCATED, MATURED, CANCELLED }
