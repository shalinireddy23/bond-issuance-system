package com.bis.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "maturity_payment", uniqueConstraints = @UniqueConstraint(columnNames = "subscription_id"))
public class MaturityPayment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "bond_id") private Bond bond;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "subscription_id") private Subscription subscription;
    @Column(name = "payment_date", nullable = false) private LocalDate paymentDate;
    @Column(nullable = false, precision = 24, scale = 8) private BigDecimal amount;

    protected MaturityPayment() {}
    public MaturityPayment(Bond bond, Subscription subscription, LocalDate paymentDate, BigDecimal amount) {
        this.bond = bond;
        this.subscription = subscription;
        this.paymentDate = paymentDate;
        this.amount = amount;
    }
    public Long getId() { return id; }
    public Bond getBond() { return bond; }
    public Subscription getSubscription() { return subscription; }
    public LocalDate getPaymentDate() { return paymentDate; }
    public BigDecimal getAmount() { return amount; }
}