package com.bis.domain;

public enum SubscriptionStatus { PENDING, ALLOCATED, REJECTED }
