package com.bis.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "subscription", uniqueConstraints = @UniqueConstraint(columnNames = {"bond_id", "investor_id"}))
public class Subscription {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne(fetch = FetchType.LAZY, optional = false) @JoinColumn(name = "bond_id") private Bond bond;
    @Column(name = "investor_id", nullable = false, length = 7) private String investorId;
    @Column(nullable = false) private Long quantity;
    @Column(name = "allocated_quantity") private Long allocatedQuantity;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private SubscriptionStatus status;
    @Column(name = "created_at", nullable = false) private Instant createdAt;
    protected Subscription() {}
    public Subscription(Bond bond, String investorId, Long quantity, Instant createdAt) {
        this.bond = bond; this.investorId = investorId; this.quantity = quantity; this.createdAt = createdAt; this.status = SubscriptionStatus.PENDING;
    }
    public Long getId() { return id; }
    public Bond getBond() { return bond; }
    public String getInvestorId() { return investorId; }
    public Long getQuantity() { return quantity; }
    public Long getAllocatedQuantity() { return allocatedQuantity; }
    public SubscriptionStatus getStatus() { return status; }
    public Instant getCreatedAt() { return createdAt; }
    public void allocate(long quantity) {
        this.allocatedQuantity = quantity;
        this.status = quantity > 0 ? SubscriptionStatus.ALLOCATED : SubscriptionStatus.REJECTED;
    }
}
