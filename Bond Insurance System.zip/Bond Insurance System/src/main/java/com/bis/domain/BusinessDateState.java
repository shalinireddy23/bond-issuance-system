package com.bis.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.time.LocalDate;

@Entity
@Table(name = "business_date_state")
public class BusinessDateState {
    @Id
    private Long id;
    private LocalDate businessDate;
    protected BusinessDateState() {}
    public BusinessDateState(Long id, LocalDate businessDate) { this.id = id; this.businessDate = businessDate; }
    public Long getId() { return id; }
    public LocalDate getBusinessDate() { return businessDate; }
    public void setBusinessDate(LocalDate businessDate) { this.businessDate = businessDate; }
}
