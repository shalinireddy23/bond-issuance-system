package com.bis.domain;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "bond")
public class Bond {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, unique = true, length = 12)
    private String isin;
    @Column(name = "issuer_name", nullable = false) private String issuerName;
    @Column(name = "bond_name", nullable = false) private String bondName;
    @Column(nullable = false, length = 3, columnDefinition = "CHAR(3)") private String currency;
    @Column(name = "face_value", nullable = false, precision = 19, scale = 2) private BigDecimal faceValue;
    @Column(name = "coupon_rate", nullable = false, precision = 10, scale = 4) private BigDecimal couponRate;
    @Column(name = "maturity_date", nullable = false) private LocalDate maturityDate;
    @Column(name = "total_size", nullable = false) private Long totalSize;
    @Column(name = "book_open_date", nullable = false) private LocalDate bookOpenDate;
    @Column(name = "book_close_date", nullable = false) private LocalDate bookCloseDate;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private BondStatus status;

    public Bond() {}
    public Long getId() { return id; }
    public String getIsin() { return isin; }
    public void setIsin(String isin) { this.isin = isin; }
    public String getIssuerName() { return issuerName; }
    public void setIssuerName(String issuerName) { this.issuerName = issuerName; }
    public String getBondName() { return bondName; }
    public void setBondName(String bondName) { this.bondName = bondName; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public BigDecimal getFaceValue() { return faceValue; }
    public void setFaceValue(BigDecimal faceValue) { this.faceValue = faceValue; }
    public BigDecimal getCouponRate() { return couponRate; }
    public void setCouponRate(BigDecimal couponRate) { this.couponRate = couponRate; }
    public LocalDate getMaturityDate() { return maturityDate; }
    public void setMaturityDate(LocalDate maturityDate) { this.maturityDate = maturityDate; }
    public Long getTotalSize() { return totalSize; }
    public void setTotalSize(Long totalSize) { this.totalSize = totalSize; }
    public LocalDate getBookOpenDate() { return bookOpenDate; }
    public void setBookOpenDate(LocalDate bookOpenDate) { this.bookOpenDate = bookOpenDate; }
    public LocalDate getBookCloseDate() { return bookCloseDate; }
    public void setBookCloseDate(LocalDate bookCloseDate) { this.bookCloseDate = bookCloseDate; }
    public BondStatus getStatus() { return status; }
    public void setStatus(BondStatus status) { this.status = status; }
}
