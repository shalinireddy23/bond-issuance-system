package com.bis.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "processed_upload_file")
public class ProcessedUploadFile {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false, unique = true) private String filename;
    @Column(name = "processed_at", nullable = false) private Instant processedAt;

    protected ProcessedUploadFile() {}
    public ProcessedUploadFile(String filename, Instant processedAt) {
        this.filename = filename;
        this.processedAt = processedAt;
    }
}