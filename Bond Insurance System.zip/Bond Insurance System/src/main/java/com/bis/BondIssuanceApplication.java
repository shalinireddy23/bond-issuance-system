package com.bis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class BondIssuanceApplication {
    public static void main(String[] args) {
        SpringApplication.run(BondIssuanceApplication.class, args);
    }
}
