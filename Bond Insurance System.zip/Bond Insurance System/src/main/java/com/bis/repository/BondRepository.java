package com.bis.repository;

import com.bis.domain.Bond;
import com.bis.domain.BondStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.repository.query.Param;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface BondRepository extends JpaRepository<Bond, Long> {
    Optional<Bond> findByIsin(String isin);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select b from Bond b where b.isin = :isin")
    Optional<Bond> findByIsinForUpdate(@Param("isin") String isin);

    List<Bond> findAllByStatus(BondStatus status);
}
