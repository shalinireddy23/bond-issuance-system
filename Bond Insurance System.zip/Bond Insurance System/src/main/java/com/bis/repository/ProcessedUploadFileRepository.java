package com.bis.repository;

import com.bis.domain.ProcessedUploadFile;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProcessedUploadFileRepository extends JpaRepository<ProcessedUploadFile, Long> {
    boolean existsByFilename(String filename);
}