package com.bis.repository;

import com.bis.domain.CouponPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface CouponPaymentRepository extends JpaRepository<CouponPayment, Long> {
    boolean existsBySubscriptionIdAndPaymentDate(Long subscriptionId, LocalDate paymentDate);
    List<CouponPayment> findAllBySubscriptionInvestorId(String investorId);
}