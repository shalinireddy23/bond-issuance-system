package com.bis.repository;

import com.bis.domain.MaturityPayment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface MaturityPaymentRepository extends JpaRepository<MaturityPayment, Long> {
    List<MaturityPayment> findAllBySubscriptionInvestorId(String investorId);
}