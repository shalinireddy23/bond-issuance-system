package com.bis.repository;

import com.bis.domain.Subscription;
import com.bis.domain.SubscriptionStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {
    Optional<Subscription> findByBondIdAndInvestorId(Long bondId, String investorId);
    List<Subscription> findAllByBondId(Long bondId);
    List<Subscription> findAllByBondIdAndStatus(Long bondId, SubscriptionStatus status);
    List<Subscription> findAllByInvestorId(String investorId);
}
