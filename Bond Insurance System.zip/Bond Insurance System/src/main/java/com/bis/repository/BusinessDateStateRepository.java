package com.bis.repository;

import com.bis.domain.BusinessDateState;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BusinessDateStateRepository extends JpaRepository<BusinessDateState, Long> {}
