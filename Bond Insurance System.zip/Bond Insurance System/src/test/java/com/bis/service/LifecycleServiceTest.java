package com.bis.service;

import com.bis.domain.*;
import com.bis.repository.*;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class LifecycleServiceTest {
    private final BondRepository bonds = mock(BondRepository.class);
    private final SubscriptionRepository subscriptions = mock(SubscriptionRepository.class);
    private final CouponPaymentRepository coupons = mock(CouponPaymentRepository.class);
    private final MaturityPaymentRepository maturities = mock(MaturityPaymentRepository.class);
    private final LifecycleService lifecycle = new LifecycleService(bonds, subscriptions, coupons, maturities);

    @Test
    void allocatesOversubscribedOrdersUsingFloorProportion() {
        Bond bond = bond(BondStatus.OPEN, 100000, LocalDate.of(2026, 6, 25));
        Subscription first = subscription(bond, 40000);
        Subscription second = subscription(bond, 30000);
        Subscription third = subscription(bond, 50000);
        when(bonds.findAll()).thenReturn(List.of(bond));
        when(subscriptions.findAllByBondId(null)).thenReturn(List.of(first, second, third));

        lifecycle.process(LocalDate.of(2026, 6, 11));

        assertEquals(SubscriptionStatus.ALLOCATED, first.getStatus());
        assertEquals(33333L, first.getAllocatedQuantity());
        assertEquals(25000L, second.getAllocatedQuantity());
        assertEquals(41666L, third.getAllocatedQuantity());
        assertEquals(BondStatus.ALLOCATED, bond.getStatus());
    }

    @Test
    void paysCouponOnBusinessMaturityDateThenReturnsPrincipal() {
        Bond bond = bond(BondStatus.ALLOCATED, 100000, LocalDate.of(2026, 6, 25));
        Subscription subscription = subscription(bond, 100);
        subscription.allocate(100);
        when(bonds.findAll()).thenReturn(List.of(bond));
        when(subscriptions.findAllByBondIdAndStatus(bond.getId(), SubscriptionStatus.ALLOCATED)).thenReturn(List.of(subscription));
        when(coupons.existsBySubscriptionIdAndPaymentDate(subscription.getId(), LocalDate.of(2026, 6, 25))).thenReturn(false);

        lifecycle.process(LocalDate.of(2026, 6, 25));

        verify(coupons).save(any());
        verify(maturities).save(any());
        assertEquals(BondStatus.MATURED, bond.getStatus());
    }

    private static Bond bond(BondStatus status, long totalSize, LocalDate maturity) {
        Bond bond = new Bond();
        bond.setIsin("MYBND2600001");
        bond.setBondName("Test Bond");
        bond.setFaceValue(new BigDecimal("1000.00"));
        bond.setCouponRate(new BigDecimal("0.0005"));
        bond.setTotalSize(totalSize);
        bond.setBookOpenDate(LocalDate.of(2026, 6, 1));
        bond.setBookCloseDate(LocalDate.of(2026, 6, 10));
        bond.setMaturityDate(maturity);
        bond.setStatus(status);
        return bond;
    }

    private static Subscription subscription(Bond bond, long quantity) {
        return new Subscription(bond, "INV-001", quantity, java.time.Instant.now());
    }
}