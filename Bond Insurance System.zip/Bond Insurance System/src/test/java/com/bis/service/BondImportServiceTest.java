package com.bis.service;

import com.bis.repository.BondRepository;
import com.bis.repository.ProcessedUploadFileRepository;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class BondImportServiceTest {
    private final BondRepository bonds = mock(BondRepository.class);
    private final ProcessedUploadFileRepository files = mock(ProcessedUploadFileRepository.class);
    private final BondImportService importer = new BondImportService(bonds, files);

    @Test
    void importsValidFileAsPendingBondAndRecordsFilename() {
        String csv = "isin,issuerName,bondName,currency,faceValue,couponRate,maturityDate,totalSize,bookOpenDate,bookCloseDate\n"
                + "MYBND2600001,ACME Corp,ACME Notes,MYR,1000.00,0.0005,2026-06-25,100000,2026-06-01,2026-06-10\n";
        when(files.existsByFilename("BONDS_20260601_001.csv")).thenReturn(false);
        when(bonds.findByIsin("MYBND2600001")).thenReturn(java.util.Optional.empty());

        assertEquals(1, importer.importFile("BONDS_20260601_001.csv",
                new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8))));
        ArgumentCaptor<com.bis.domain.Bond> bond = ArgumentCaptor.forClass(com.bis.domain.Bond.class);
        verify(bonds).save(bond.capture());
        assertEquals(com.bis.domain.BondStatus.PENDING, bond.getValue().getStatus());
        verify(files).save(any());
    }

    @Test
    void rejectsMalformedHeaderBeforePersistingAnything() {
        String csv = "wrong,header\nvalue\n";
        assertThrows(IllegalArgumentException.class, () -> importer.importFile("bad.csv",
                new ByteArrayInputStream(csv.getBytes(StandardCharsets.UTF_8))));
        verifyNoInteractions(bonds);
        verify(files).existsByFilename("bad.csv");
    }

    @Test
    void rejectsDuplicateFilename() {
        when(files.existsByFilename("BONDS_20260601_001.csv")).thenReturn(true);
        assertThrows(IllegalStateException.class, () -> importer.importFile("BONDS_20260601_001.csv",
                new ByteArrayInputStream(new byte[0])));
        verifyNoInteractions(bonds);
    }
}