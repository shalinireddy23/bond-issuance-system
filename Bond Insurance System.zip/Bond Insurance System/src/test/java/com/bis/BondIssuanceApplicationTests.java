package com.bis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BondIssuanceApplicationTests {
    @Test
    void contextLoads() {}
}
